🟢 Potato Dashboard - Online Market Intelligence App

Developed by: Farrukh Ahmad Malik
Version: 1.0.0
Date: July 2025

=========================================================

A lightweight desktop application to monitor and visualize potato commodity data — no installation required.

📦 What's Inside
---------------------------------------------------------
- Potato Dashboard.exe — the single-click app
- README.txt — you're reading it!


🚀 How to Use
---------------------------------------------------------
1. Download and unzip the release `.zip` file.
2. Double-click `Potato Dashboard.exe`.
3. If the app launches with a blank or white window, follow the fix below.


⚠️ If the App Is Blank or Doesn't Show UI
---------------------------------------------------------
Sometimes the required components are missing on your system. Install the following:

✅ Step 1: Install Visual C++ Redistributable
Required for running Python-based desktop apps.
- Download (x64): https://aka.ms/vs/17/release/vc_redist.x64.exe

✅ Step 2: Install Microsoft Edge WebView2 Runtime
This is used to render the app interface.
- Download (Evergreen Bootstrapper): https://go.microsoft.com/fwlink/p/?LinkId=2124703


🛡 Antivirus Warning?
---------------------------------------------------------
If Windows SmartScreen or Defender warns you:
- Click More info → Run anyway
- Or right-click the `.exe` → Properties → check Unblock, then click OK

🔒 This app does not access your files or network without permission.


📬 Feedback / 📞 Support?
---------------------------------------------------------
Report bugs or suggestions at:
Github: https://github.com/fallute/PotatoDashboard
Email: amfarrukh327@gmail.com 